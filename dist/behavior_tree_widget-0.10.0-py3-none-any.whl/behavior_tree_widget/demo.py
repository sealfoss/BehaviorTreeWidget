"""Demo application with a few example leaf nodes.

Run it with ``python -m behavior_tree_widget [tree.json]`` or the
``behavior-tree-widget-demo`` command installed with the package.
"""

from __future__ import annotations

import functools
import logging
import random
import sys
import time
from typing import override

from PySide6.QtCore import QFile
from PySide6.QtWidgets import QApplication, QLabel, QMainWindow, QMessageBox

from . import BehaviorTreeWidget, LeafNodeWidget, Status

log = logging.getLogger("behavior_tree_widget.demo")


class Wait(LeafNodeWidget):
    """Waits for a number of seconds (runs on a worker thread, can be cancelled)."""

    _title = "Wait"
    _fields = {"seconds": 1.0}

    @override
    def OnRun(self, tree):
        deadline = time.monotonic() + max(0.0, self.GetField("seconds"))
        while time.monotonic() < deadline:
            if self.CancelRequested():
                return False
            time.sleep(0.02)
        return True


class LogMessage(LeafNodeWidget):
    """Writes a message to the log and to the "last_message" blackboard entry."""

    _title = "Log Message"
    _fields = {"message": "Hello from the behavior tree!", "level": ["INFO", "WARNING", "ERROR"]}
    RUN_IN_THREAD = False  # quick, runs on the GUI thread

    @override
    def OnRun(self, tree):
        level = getattr(logging, self.GetFieldSelection("level"), logging.INFO)
        message = self.GetField("message")
        log.log(level, message)
        tree.SetEntry(message, "last_message")
        return True


class IncrementCounter(LeafNodeWidget):
    """Adds ``step`` to an Integer blackboard entry (created when missing)."""

    _title = "Increment Counter"
    _fields = {"entry": "counter", "step": 1}
    RUN_IN_THREAD = False

    @override
    def OnRun(self, tree):
        name = self.GetField("entry")
        value = tree.GetEntry(name) if tree.HasEntry(name) else 0
        tree.SetEntry(value + self.GetField("step"), name)
        return True


class CounterAtLeast(LeafNodeWidget):
    """Condition: succeeds when an Integer blackboard entry is >= ``threshold``."""

    _title = "Counter At Least"
    _fields = {"entry": "counter", "threshold": 3}
    RUN_IN_THREAD = False

    @override
    def OnRun(self, tree):
        name = self.GetField("entry")
        return tree.HasEntry(name) and tree.GetEntry(name) >= self.GetField("threshold")


class RandomOutcome(LeafNodeWidget):
    """Succeeds with the given probability."""

    _title = "Random Outcome"
    _fields = {"success_probability": 0.5}
    RUN_IN_THREAD = False

    @override
    def OnRun(self, tree):
        return random.random() < self.GetField("success_probability")


class MoveTo(LeafNodeWidget):
    """Simulates moving to (x, y); shows every field type. Writes "position" to the blackboard."""

    _title = "Move To"
    _fields = {
        "x": 5.0,
        "y": 2.5,
        "speed": 5,
        "mode": ["walk", "run", "crawl"],
        "avoid_obstacles": True,
        "label": "target",
    }

    @override
    def OnRun(self, tree):
        position = tree.GetEntry("position") if tree.HasEntry("position") else [0.0, 0.0]
        target = [self.GetField("x"), self.GetField("y")]
        factor = {"walk": 1.0, "run": 2.0, "crawl": 0.25}[self.GetFieldSelection("mode")]
        step = max(1, self.GetField("speed")) * factor * 0.05
        while True:
            if self.CancelRequested():
                return False
            delta = [t - p for t, p in zip(target, position, strict=True)]
            distance = (delta[0] ** 2 + delta[1] ** 2) ** 0.5
            if distance <= step:
                tree.SetEntry(target, "position")
                return True
            position = [p + d / distance * step for p, d in zip(position, delta, strict=True)]
            tree.SetEntry([round(p, 3) for p in position], "position")
            time.sleep(0.05)


class Fail(LeafNodeWidget):
    """Always fails."""

    _title = "Fail"
    RUN_IN_THREAD = False

    @override
    def OnRun(self, tree):
        return False


class RunningTicks(LeafNodeWidget):
    """Returns RUNNING for ``ticks`` ticks, then succeeds (polling style, GUI thread)."""

    _title = "Running For Ticks"
    _fields = {"ticks": 3}
    RUN_IN_THREAD = False

    @override
    def OnStart(self, tree):
        self._remaining = self.GetField("ticks")

    @override
    def OnRun(self, tree):
        if self._remaining > 0:
            self._remaining -= 1
            return Status.RUNNING
        return True


DEMO_NODE_TYPES = [Wait, LogMessage, IncrementCounter, CounterAtLeast, RandomOutcome, MoveTo, Fail, RunningTicks]


class DemoWindow(QMainWindow):
    """Main window hosting a BehaviorTreeWidget with the demo node types."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Behavior Tree")
        self.tree = BehaviorTreeWidget(node_types=DEMO_NODE_TYPES)
        self.setCentralWidget(self.tree)
        self._status = QLabel("Click New to create a tree or Load to open one.")
        self.statusBar().addWidget(self._status, 1)
        self.tree.executionStateChanged.connect(lambda state: self._status.setText(f"Execution: {state}"))
        self.tree.executionFinished.connect(lambda result: self._status.setText(f"Execution finished: {result}"))
        self.tree.nodeError.connect(lambda node, message: self._status.setText(f"{node.GetTitle()}: {message}"))
        self.tree.treeLoaded.connect(lambda path: self._status.setText(f"Loaded {path}"))
        self.tree.treeSaved.connect(lambda path: self._status.setText(f"Saved {path}"))
        # The tree's log (Print Message nodes log at DEBUG by default); INFO lists every node run.
        for level, signal in (("ERROR", self.tree.errorLogged), ("WARNING", self.tree.warningLogged),
                              ("DEBUG", self.tree.debugLogged)):
            signal.connect(
                lambda message, level=level: self._status.setText(f"{level}: {(message.splitlines() or [''])[0]}")
            )
        self.resize(1000, 720)

    @override
    def closeEvent(self, event):
        if not self.tree.ConfirmDiscardChanges():
            event.ignore()
            return
        self.tree.Shutdown()
        super().closeEvent(event)


def _unconsumed_arguments(argv: list[str], arguments: list[str]) -> list[str]:
    """``argv`` without the entries QApplication consumed (its options, e.g. ``-style fusion``).

    ``arguments`` is ``QApplication.arguments()``. Qt only removes entries, but it decodes them
    with the local 8-bit code page, which garbles other characters (e.g. in file names on
    Windows), so the kept entries are taken from ``argv``. Qt removes options (``-name``) and the
    values following them; every way of removing such entries that leaves ``arguments`` is
    considered. If they keep different strings (a garbled name can look like an option's value),
    ``arguments`` is returned.
    """
    removable = len(argv) - len(arguments)  # the number of entries Qt consumed
    if not argv or removable < 0:
        return list(arguments)

    def same(arg: str, qt_arg: str) -> bool:
        return arg == qt_arg or QFile.decodeName(QFile.encodeName(arg)) == qt_arg

    @functools.cache
    def kept(position: int, index: int, waiting: int) -> frozenset[tuple[str, ...]]:
        """The entries ``argv[position:]`` can keep while leaving ``arguments[index:]`` (at most two
        different ones); ``waiting``: options removed before ``position`` whose value was not."""
        if position == len(argv):
            return frozenset({()}) if index == len(arguments) else frozenset()
        arg = argv[position]
        ways: set[tuple[str, ...]] = set()
        if index < len(arguments) and same(arg, arguments[index]):
            ways.update((arg, *rest) for rest in kept(position + 1, index + 1, 0))
        if position - index < removable:  # Qt may have removed this entry
            if arg.startswith("-"):
                ways.update(kept(position + 1, index, waiting + 1))  # an option
            elif waiting:
                ways.update(kept(position + 1, index, waiting - 1))  # the value of an option
        return frozenset(list(ways)[:2])

    results = kept(1, 1, 0)
    return [argv[0], *next(iter(results))] if len(results) == 1 else list(arguments)


def main(argv: list[str] | None = None) -> int:
    """Start the demo application. An optional argument names a tree file to load."""
    argv = list(sys.argv if argv is None else argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    app = QApplication.instance()
    if app is None:
        app = QApplication(argv)
        arguments = _unconsumed_arguments(argv, app.arguments())  # without Qt options such as -style
    else:
        arguments = argv
    window = DemoWindow()
    window.show()
    if len(arguments) > 1:
        try:
            window.tree.LoadTree(arguments[1])
        except Exception as error:  # noqa: BLE001
            log.error("could not load %s: %s", arguments[1], error)
            QMessageBox.critical(window, "Load Behavior Tree", f"Could not load '{arguments[1]}':\n{error}")
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
